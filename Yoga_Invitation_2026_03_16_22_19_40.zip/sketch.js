let inviteY = 420;

function setup() {
  createCanvas(800, 600);
  textAlign(CENTER);
  textFont("Helvetica");
}

function draw() {
  background(200, 230, 255);


  // invitation slides upward
  if (inviteY > 200) {
    inviteY -= 1.5;
  }

  fill(mouseX/3, mouseY/3, 150);

  textSize(45);
  text("Summer Yoga!", width/2, inviteY);

  textSize(20);
  text("Golden Gate Park", width/2, inviteY + 30);

  text("June 1 • July 1 • August 1 • Sept 1", width/2, inviteY + 60);

  text("8am - 10am", width/2, inviteY + 90);

  drawEnvelope();
}

function drawEnvelope() {

  // envelope body
  fill(255);
  rect(200, 400, 400, 150);
  noStroke(0)

  // envelope opening
  fill(230);
  triangle(200, 400, 600, 400, 400, 320);
}